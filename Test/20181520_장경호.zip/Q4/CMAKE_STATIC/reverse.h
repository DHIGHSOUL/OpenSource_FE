char* reversecopy(int argc, char** argv);
int getLastNumber(char** argv);