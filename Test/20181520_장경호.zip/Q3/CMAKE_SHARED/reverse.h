char* reversecopy(int argc, char** argv);
